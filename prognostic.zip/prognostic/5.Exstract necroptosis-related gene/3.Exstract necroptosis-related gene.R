library(limma)
rt<-read.csv("symbol.csv",check.names = F)
rt<-as.matrix(rt)
row.names(rt)<-rt[,1]
exp<-rt[,2:ncol(rt)]
dimnames<-list(row.names(exp),colnames(exp))
data<-matrix(as.numeric(as.matrix(exp)),nrow = nrow(exp),dimnames = dimnames)
data<-avereps(data)
data<-data[rowMeans(data)>0,]

gene<-read.table("gene.txt",header = F,check.names = F,sep = "\t")
samGene<-intersect(as.vector(gene[,1]),rownames(data))
geneExp<-data[samGene,]

out<-rbind(ID=colnames(geneExp),geneExp)
write.table(out,file = "necroptosisexp.txt",sep = "\t",quote = F,col.names = F)
