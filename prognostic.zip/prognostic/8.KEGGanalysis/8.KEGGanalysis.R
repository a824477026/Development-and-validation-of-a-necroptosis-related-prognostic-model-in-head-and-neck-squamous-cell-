
data_sgni<-read.table("gene.txt",sep = "\t",check.names = F,header = T)


##BiocManager::install("org.Mm.eg.db")
library(clusterProfiler)
library(topGO)
library(Rgraphviz)
library(org.Hs.eg.db)
library(pathview)
library(ggplot2)
library(GOplot)
library(dplyr)
library(clusterProfiler)
library(ggplot2)
entrez_id_full=mapIds(x=org.Hs.eg.db,
                      keys = data_sgni$gene,
                      keytype = "SYMBOL",
                      column = "ENTREZID")
entrez_id<-na.omit(entrez_id_full)
ENTREZID<-data.frame(entrez_id,row.names =nrow(entrez_id))

data_sgni$entrez<-entrez_id



kk<-enrichKEGG(gene =entrez_id, organism = "hsa",pvalueCutoff = 0.05,qvalueCutoff=0.05 )
write.table(kk,file = "KEGGID.txt",sep = "\t",quote = F,row.names = F)


pdf(file = "barplot.pdf",width = 10,height = 7)
barplot(kk,drop=TRUE,showCategory = 30)
dev.off()


pdf(file = "bubble.pdf",width = 10,height = 7)
dotplot(kk,showCategory = 30)
dev.off()

go<-data.frame(Category="ALL",ID=kk@result$ID,Term=kk@result$Description,
               Genes=gsub("/",", ", kk@result$geneID),adj_pval=kk@result$p.adjust)

genelist<-data.frame(ID=data_sgni$entrez,logFC=data_sgni$logFC)
row.names(genelist)<-genelist[,1]
circ<-circle_dat(go,genelist)


pdf(file = "KEGGCircle.pdf",width = 15,height = 9)
GOCircle(circ,rad1=2.5,rad2 = 3.5,label.size = 4,nsub = 10)
dev.off()










