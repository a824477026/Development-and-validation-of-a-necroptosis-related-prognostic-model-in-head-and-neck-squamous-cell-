options(stringsAsFactors = F)

if(file.exists("03-SampleFiles")== FALSE){dir.create("03-SampleFiles")}

if(file.exists("04-outputFiles")== FALSE){dir.create("04-outputFiles")}

if(file.exists("05-geneExpMatrix")== FALSE){dir.create("05-geneExpMatrix")}


getFile <- function(fp){
 
  filepath <- dir(path =fp,full.names = TRUE)
  for(wd in filepath){
    files <-dir(path = wd,pattern="gz$")
    fromfilepath <- paste(wd,"\\",files,sep ="")
    tofilepath <- paste(".\\03-SampleFiles\\",files,sep ="")
    file.copy(fromfilepath,tofilepath)
  }

  Files <-dir(path = ".\\03-SampleFiles",pattern="gz$") 
  setwd(".\\03-SampleFiles")
  library(R.utils)
  sapply(Files, gunzip) 
  setwd("..\\")
}
getFile("01-FPKM-Data")



processingJsonFiles <- function(jsonFile){
  library(rjson)
  metadata_json_File <- fromJSON(file=jsonFile)
  json_File_Info <- data.frame(filesName = c(),TCGA_Barcode = c())
  for(i in 1:length(metadata_json_File)){
    TCGA_Barcode <- metadata_json_File[[i]][["associated_entities"]][[1]][["entity_submitter_id"]]
    file_name <- metadata_json_File[[i]][["file_name"]]
    json_File_Info <- rbind(json_File_Info,data.frame(filesName = file_name,TCGA_Barcode = TCGA_Barcode))
  }
  rownames(json_File_Info) <- json_File_Info[,1]
  json_File_Info <-json_File_Info[-1]
  write.table(json_File_Info,file = ".\\04-outputFiles\\json_File_Info.txt")
  return(json_File_Info)
}
jsonFilePath <- ".\\02-PrepaFiles\\metadata.cart.2021-10-02.json"####修改文件名
json_File_Info <- processingJsonFiles(jsonFilePath)



getExpMatrix <- function(SampleFilesPath,Barcode){
  setwd(SampleFilesPath)
  if(file.exists("MANIFEST.txt")){file.remove("MANIFEST.txt")}
  FPKM_FileNames<-dir(pattern="txt$") 
  allSampleFPKM <- data.frame()
  for(txtFile in FPKM_FileNames){

    SampleFPKM <- read.table(txtFile,header =FALSE)
    rownames(SampleFPKM) <- SampleFPKM[,1]
    SampleFPKM <- SampleFPKM[-1]

    colnames(SampleFPKM) <-Barcode[paste(txtFile,".gz",sep = ""),]
    if (dim(allSampleFPKM)[1]== 0){
      allSampleFPKM <- SampleFPKM
    }
    else 
    {allSampleFPKM<- cbind(allSampleFPKM,SampleFPKM)}
  }
  write.table(allSampleFPKM,file = "..\\05-geneExpMatrix\\expMatrix-1.txt")
  library(stringr)
  ids=c(str_split(rownames(allSampleFPKM),'[.]',simplify = T)[,1])
  rownames(allSampleFPKM) <- ids
  write.table(allSampleFPKM,file = "..\\05-geneExpMatrix\\expMatrix-2.txt")
  setwd("..\\")
  return(allSampleFPKM)
}
#
SampleFilesPath <- ".\\03-SampleFiles"
Barcode <- json_File_Info 
geneExpMatrix <- getExpMatrix(SampleFilesPath,Barcode)
write.csv(geneExpMatrix,"05-geneExpMatrix\\geneExpMatrix.csv")

library(AnnoProbe)
Ensembl_ID_TO_Genename=annoGene(rownames(geneExpMatrix),"ENSEMBL","human")
write.csv(Ensembl_ID_TO_Genename,".\\04-outputFiles\\Ensembl_ID_TO_Genename&biotype.csv")
write.csv(Ensembl_ID_TO_Genename[,c(1,3)],".\\04-outputFiles\\Ensembl_ID_TO_Genename.csv")
Ensembl_ID_TO_Genename<-Ensembl_ID_TO_Genename[,c(1,3)]
colnames(Ensembl_ID_TO_Genename)<-c("gene_id","Ensembl_ID")

mergeGeneExpData <- function(ExpMatrix,ensemblTransferFile){

  library(limma)
  Ensembl_ID <- data.frame(Ensembl_ID = row.names(ExpMatrix))
  rownames(Ensembl_ID) <- Ensembl_ID[,1]
  ExpMatrix <- cbind(Ensembl_ID,ExpMatrix)

  mergeExpMatrix <- merge(ensemblTransferFile,ExpMatrix,by="Ensembl_ID")

  mergeExpMatrix <- mergeExpMatrix[order(mergeExpMatrix[,"gene_id"]),]

  geneNames<- mergeExpMatrix[,2]
  mergeExpMatrix <- mergeExpMatrix[,-c(1,2)]
  mergeExpMatrix <- as.matrix(mergeExpMatrix)
  rownames(mergeExpMatrix) <- as.vector(geneNames)
  mergeExpMatrix <- avereps(mergeExpMatrix)
  mergeExpMatrix <- as.data.frame(mergeExpMatrix)
  write.table(ensemblTransferFile,file = ".\\05-geneExpMatrix\\expMatrix-3.txt")
  return(mergeExpMatrix)
}
ExpMatrix <- mergeGeneExpData(geneExpMatrix,Ensembl_ID_TO_Genename)
##########区分正常样本和肿瘤样本
### 读入数据,这里我们前面的变量ExpMatrix_expMatrix就是我们要的数据，
### 所以不需要读入
library(TCGAbiolinks)
# 请求数据。如果前面下载数据不是通过TCGAbiolinks包下载的话可通过该包请求数据
query <- GDCquery(project = "TCGA-HNSC",
                  data.category = "Transcriptome Profiling",
                  data.type = "Gene Expression Quantification", 
                  workflow.type = "HTSeq - FPKM")
# 从query中获取结果表，它可以选择带有cols参数的列，并使用rows参数返回若干行。
samplesDown <- getResults(query,cols=c("cases"))

# 肿瘤样本的barcode
dataSmTP <- TCGAquery_SampleTypes(barcode = samplesDown, 
                                  typesample = c("TP","TM"))# 正常组织的barcode
dataSmNT <- TCGAquery_SampleTypes(barcode = samplesDown,
                                  typesample = "NT")
# 重新排序样本顺序，正常组织样本在前，肿瘤样本在后
ExpMatrix<- cbind(id=row.names(ExpMatrix),ExpMatrix[,dataSmNT],ExpMatrix[,dataSmTP]) 
write.csv(ExpMatrix,"symbol.csv",row.names = F)







