library(limma)
GPL<-read.table("GPL.txt",check.names = F,sep = "\t",header = T)
GSE<-read.table("GSE.txt",check.names = F,sep = "\t",header = T)
geneMatrix<-merge(GPL,GSE,by="ID")
geneMatrix<-na.omit(geneMatrix)
geneMatrix<-geneMatrix[,2:ncol(geneMatrix)]

geneNames<- geneMatrix[,1]
geneExpMatrix <- geneMatrix[,-1]
geneExpMatrix <- as.matrix(geneExpMatrix)
rownames(geneExpMatrix) <- as.vector(geneNames)
geneExpMatrix <- avereps(geneExpMatrix)
geneExpMatrix <- as.data.frame(geneExpMatrix)
id<-row.names(geneExpMatrix)
geneExpMatrix<-data.frame(id=id,geneExpMatrix)


write.table(geneExpMatrix,"geneMatrix.txt",sep = "\t",row.names = F)
