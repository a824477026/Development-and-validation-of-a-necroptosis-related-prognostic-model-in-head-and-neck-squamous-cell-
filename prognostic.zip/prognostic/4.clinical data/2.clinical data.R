rm(list = ls())
options(stringsAsFactors = F)




clinicaldir <- "Clindata"


library(XML)
library(methods)
xmlFileNames<-dir(path = clinicaldir,full.names = T,
                  pattern="xml$",recursive = T)

AllPatiCliniList <- lapply(xmlFileNames,
                           function(x){
                             result <- xmlParse(file = x) 
                             rootnode <- xmlRoot(result)  
                             xmldataframe <- xmlToDataFrame(rootnode[2]) 
                             return(t(xmldataframe))})

AllPatiCliniList  <- t(do.call(cbind,AllPatiCliniList))
pClinData <- data.frame(Barcode = AllPatiCliniList[,"bcr_patient_barcode"],
                        gender=AllPatiCliniList[,"gender"],
                        grade=AllPatiCliniList[,"neoplasm_histologic_grade"],
                        age=AllPatiCliniList[,"age_at_initial_pathologic_diagnosis"],
                        fustat = AllPatiCliniList[,"vital_status"],
                        days_to_death = AllPatiCliniList[,"days_to_death"],
                        lastFollowupTime = AllPatiCliniList[,"days_to_last_followup"],
                        Stage = AllPatiCliniList[,"stage_event"])

rownames(pClinData ) <- pClinData [,"Barcode"]
splitStage <- function(Stage){
  stage <- unlist(strsplit(Stage,split = "[S]"))[2]
  stage <- unlist(strsplit(stage, split = "T"))[1]
  stage <- paste("S",stage,sep = "")
  
  Tstage <- unlist(strsplit(Stage,split = "[T]"))[2]
  Tstage <- unlist(strsplit(Tstage, split = "N"))[1]
  Tstage <- paste("T",Tstage,sep = "")
  
  Nstage <- unlist(strsplit(Stage,split = "[N]"))[2]
  Nstage <- unlist(strsplit(Nstage, split = "M"))[1]
  Nstage <- paste("N",Nstage,sep = "")
  
  Mstage <- unlist(strsplit(Stage,split = "[M]"))[2]
  Mstage <- paste("M",Mstage,sep = "")
  return(data.frame(stage,Tstage,Nstage,Mstage))
} 

SurvivalTime <-c()
Stage <-c()
T_Stage <-c()
N_Stage <-c()
M_Stage <-c()
for(id in rownames(pClinData)){
  days_to_death = as.numeric(pClinData[id,"days_to_death"])
  lastFollowupTime = as.numeric(pClinData[id,"lastFollowupTime"])
  PatientsSurvivalTime <- c()
  if(!is.na(days_to_death) ){
    PatientsSurvivalTime <- c(days_to_death)
  }else {PatientsSurvivalTime <- c(lastFollowupTime) }
  SurvivalTime <- c(SurvivalTime,PatientsSurvivalTime)
  TNMStage <- splitStage(Stage = pClinData[id,"Stage"])
  Stage <-c(Stage,TNMStage[1,"stage"])
  T_Stage <- c(T_Stage,TNMStage[1,"Tstage"])
  N_Stage <- c(N_Stage,TNMStage[1,"Nstage"]) 
  M_Stage <- c(M_Stage,TNMStage[1,"Mstage"])
}

getClinicalData <- function(pClinData){
  tempdata <-pClinData
  finallypClinData <-data.frame(id = tempdata[,"Barcode"],
                                futime = SurvivalTime,
                                                    fustat = tempdata[,"fustat"],
                                                    age = tempdata[,"age"],
                                                    gender = tempdata[,"gender"],
                                                    grade = tempdata[,"grade"],
                                                    AllStage = tempdata[,"Stage"],
                                                    Stage = Stage,
                                                    T_Stage = T_Stage,
                                                    N_Stage = N_Stage,
                                                    M_Stage = M_Stage)
  return(finallypClinData)
}
tidypClinData<-getClinicalData(pClinData)



write.csv(tidypClinData,file = "ClinData.csv",)




