rt<-read.table("geneRisk.txt",header = T)
clinical<-read.table("clinical.txt",sep = "\t",header = T,check.names = F)
riskscore<-rt[,c(1,(ncol(rt)-1))]
clinical<-merge(clinical,riskscore,by="id")
write.csv(clinical,"indeplnput.csv",row.names = F)
