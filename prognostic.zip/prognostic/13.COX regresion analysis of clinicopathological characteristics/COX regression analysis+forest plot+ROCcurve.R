library(survival)
rt<-read.csv("indeplnput.csv",row.names=1,check.names = F)

uniTab<-data.frame()
for(i in colnames(rt[,3:ncol(rt)])){
  cox<-coxph(Surv(futime,fustat)~ rt[,i],data = rt)
  coxSummary<-summary(cox)
  uniTab<-rbind(uniTab,
                cbind(id=i,
                      B=coxSummary$coefficients[,"coef"],
                      SE=coxSummary$coefficients[,"se(coef)"],
                      z=coxSummary$coefficients[,"z"],
                      HR=coxSummary$conf.int[,"exp(coef)"],
                      HR.95L=coxSummary$conf.int[,"lower .95"],
                      HR.95H=coxSummary$conf.int[,"upper .95"],
                      pvalue=coxSummary$coefficients[,"Pr(>|z|)"])
                )
}
write.table(uniTab,file="uniCox.txt",sep = "\t",row.names = F,quote = F)

multicox<-coxph(Surv(futime,fustat) ~.,data = rt)
multicoxsum<-summary(multicox)
multitab<-data.frame()
multitab<-cbind(
  B=multicoxsum$coefficients[,"coef"],
  SE=multicoxsum$coefficients[,"se(coef)"],
  z=multicoxsum$coefficients[,"z"],
  HR=multicoxsum$conf.int[,"exp(coef)"],
  HR.95L=multicoxsum$conf.int[,"lower .95"],
  HR.95H=multicoxsum$conf.int[,"upper .95"],
  pvalue=multicoxsum$coefficients[,"Pr(>|z|)"])
multitab<-cbind(id=row.names(multitab),multitab)
write.table(multitab,file = "multicox.txt",sep = "\t",row.names = F,quote = F)

bioForest<-function(coxFile=null,forestFile=null){

  rt<-read.table(coxFile,header = T,sep = "\t",row.names = 1)
  gene<-rownames(rt)
  hr<-sprintf("%.3f",rt$"HR")
  hrlow<-sprintf("%.3f",rt$"HR.95L")
  hrhigh<-sprintf("%.3f",rt$"HR.95H")
  Hazard.ration<-paste0(hr,"(",hrlow,"-",hrhigh,")")
  pval<-ifelse(rt$pvalue<0.001,"<0.001",sprintf("%.3f",rt$pvalue))

  pdf(file = forestFile,width = 9,height = 6.3)
  n<-nrow(rt)
  nRow<-n+1
  ylim<-c(1,nRow)
  layout(matrix(c(1,2),nc=2),widths = c(3,2.5))
  

  xlim<-c(0,3)
  par(mar=c(4,2.5,2,1))
  plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,xlab="",ylab="")
  text.cex=0.8
  text(0,n:1,gene,adj=0,cex=text.cex)
  text(1.5-0.5*0.2,n:1,pval,adj = 1,cex=text.cex);text(1.5-0.5*0.2,n+1,"pvalue",cex = text.cex,font = 2)
  text(3,n:1,Hazard.ration,adj=1,cex=text.cex);text(3,n+1,'Hazard.ration',cex=text.cex,font=2)

  par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
  xlim=c(0,max(as.numeric(hrlow),as.numeric(hrhigh)))
  plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,ylab="",xaxs="i",xlab="Hazard.ration")
  arrows(as.numeric(hrlow),n:1,as.numeric(hrhigh),n:1,angle = 90,code = 3,length = 0.05,col = "darkblue",lwd = 3)####lwd调整线的宽度
  abline(v=1,col="black",lty=2,lwd=2)
  boxcolor=ifelse(as.numeric(hr)>1,"orange","blue")
  points(as.numeric(hr),n:1,pch=15,col=boxcolor,cex=1.3)
  axis(1)
  dev.off()
}

bioForest(coxFile = "uniCox.txt",forestFile = "uniforest.pdf")
bioForest(coxFile = "multicox.txt",forestFile = "multiforest.pdf")



library(survivalROC)
rt<-read.csv("indeplnput.csv",row.names = 1)
rt$futime<-rt$futime/365  
rocCol<-rainbow(ncol(rt)-2)
aucText<-c()

pdf(file = "multiROC.pdf",width = 6,height = 6)
par(oma=c(0.5,1,0,1),font.lab=1.5,font.axis=1.5)
roc<-survivalROC(Stime = rt$futime,status = rt$fustat,marker = rt$riskScore,
                 predict.time=5,method="KM")
plot(roc$FP,roc$TP,type = "l",xlim = c(0,1),ylim = c(0,1),col=rocCol[1],
     xlab = "False positive rate",ylab = "True positive rate",
     lwd=2,cex.main=1.3,cex.lab=1.2,cex.axis=1.2,font=1.2)
aucText<-c(aucText,paste0("risk score","(AUC=",sprintf("%.3f",roc$AUC),")"))
abline(0,1)

j=1
for(i in colnames(rt[,3:(ncol(rt)-1)])){
  roc=survivalROC(Stime = rt$futime,status = rt$fustat,marker = rt[,i],predict.time=5,method="KM")
  j=j+1
  aucText<-c(aucText,paste0(i,"(AUC=",sprintf("%.3f",roc$AUC),")"))
  lines(roc$FP,roc$TP,type="l",xlim=c(0,1),ylim=c(0,1),col=rocCol[j],lwd=2)
}
legend("bottomright",aucText,lwd = 2,bty = "n",col = rocCol)
dev.off()