library(rms)
library(survival)
risk<-read.csv("indeplnput.csv",row.name=1)
outfile<-"Nomogram.pdf"
rt<-risk[,1:(ncol(risk)-0)]
rt[,"futime"]<-rt[,"futime"]/365



dd<-datadist(rt)
options(datadist="dd")

f<-cph(Surv(futime,fustat) ~ age+gender+grade+Stage+riskScore, ########研究因素（注意大小写）。此处gender影响较小，所以不将gender带入分析
       x=T,y=T,surv = T,data = rt,time.inc = 1)
surv<-Survival(f)

nom<-nomogram(f,fun=list(function(x)surv(1, x),function(x)surv(3, x),function(x)surv(5, x)),
                         lp=F,funlabel=c("1-year survival","3-year survival","5-year survival"),
                         maxscale=100,
                         fun.at=c(0.99,0.9,0.8,0.7,0.5,0.3,0.1,0.01))

pdf(file = outfile,height = 6,width = 9)
plot(nom)
dev.off()

