library(survival)
library(survminer)
library(glmnet)
pFilter<-0.05


rt<-read.table("expTime.txt",header = T,sep = "\t",check.names = F,row.names = 1)
rt$futime<-rt$futime/365 

outTab<-data.frame()
sigGenes<-c("futime","fustat")
for(gene in colnames(rt[,3:ncol(rt)])){
  if(sd(rt[,gene])<0.01){
    next}
   
    a<-rt[,gene]<=median(rt[,gene])
    diff=survdiff(Surv(futime,fustat) ~a,data = rt)
    pValue=1-pchisq(diff$chisq,df=1)
    fit=survfit(Surv(futime,fustat) ~a,data = rt)
   
    cox<-coxph(Surv(futime,fustat) ~rt[,gene],data = rt)
    coxSummary<-summary(cox)
    coxP<-coxSummary$coefficients[,"Pr(>|z|)"]
    if((pValue<pFilter)&(coxP<pFilter)){
      sigGenes<-c(sigGenes,gene)
      outTab<-rbind(outTab,
                    cbind(gene=gene,
                          KM=pValue,
                          B=coxSummary$coefficients[,"coef"],
                          SE=coxSummary$coefficients[,"se(coef)"],
                          HR=coxSummary$conf.int[,"exp(coef)"],
                          HR.95L=coxSummary$conf.int[,"lower .95"],
                          HR.95H=coxSummary$conf.int[,"upper .95"],
                          pvalue=coxP))
    }
}
write.table(outTab,file = "uniCox.xls",sep = "\t",row.names = F,quote = F)
unisigExp<-rt[,sigGenes]
unisigExp<-cbind(id=row.names(unisigExp),unisigExp)
write.table(unisigExp,file = "uniSigExp.txt",sep = "\t",row.names = F,quote = F)

rt<-read.table("uniCox.xls",header = T,sep = "\t",row.names = 1,check.names = F)
gene<-rownames(rt)
hr<-sprintf("%.3f",rt$HR)
hrlow<-sprintf("%.3f",rt$HR.95L)
hrhigh<-sprintf("%.3f",rt$HR.95H)
Hazard.ratio<-paste0(hr,"(",hrlow,"-",hrhigh,")")
pVal<-ifelse(rt$pvalue<0.001,"0.001",sprintf("%.3f",rt$pvalue))

pdf(file = "forest.pdf",width = 6,height = 7)
n<-nrow(rt)
nRow<-n+1
ylim<-c(1,nRow)
layout(matrix(c(1,2),nc=2),widths = c(3,2))

xlim<-c(0,3)
par(mar=c(4,2.5,2,1))
plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,xlab="",ylab="")
text.cex=0.8
text(0,n:1,gene,adj=0,cex=text.cex)
text(1.5-0.5*0.2,n:1,pVal,adj = 1,cex = text.cex);text(1.5-0.5*0.6,n+1,"pvalue",cex=text.cex)
text(3.1,n:1,Hazard.ratio,adj=1,cex=text.cex);text(2.35,n+1,"Hazard ratio",cex=text.cex,font = 2)
par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
xlim=c(0,max(as.numeric(hrlow),as.numeric(hrhigh)))
plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,ylab="",xaxs="i",xlab="Hazard ratio")
arrows(as.numeric(hrlow),n:1,as.numeric(hrhigh),n:1,angle=90,code=3,length=0.05,col="darkblue")
abline(v=1,col="black",lty=2,lwd=2)
boxcolor=ifelse(as.numeric(hr)>1,"red","blue")
points(as.numeric(hr),n:1,pch=15,col=boxcolor,cex=1.3)
axis(1)
dev.off()

