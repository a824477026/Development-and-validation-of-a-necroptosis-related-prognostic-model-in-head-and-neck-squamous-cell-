library(survival)
library(survminer)
library(glmnet)
coxPfilter=0.05
rt<-read.table("uniSigExp.txt",header = T,sep = "\t",check.names = F,row.names = 1)



multicox<-coxph(Surv(futime,fustat) ~ .,data = rt)
multicox<-step(multicox,direction = "both")
multicoxSummary<-summary(multicox)
outTab<-data.frame(coef=multicoxSummary$coefficients[,"coef"],
                   HR=multicoxSummary$conf.int[,"exp(coef)"],
                   HR.95L=multicoxSummary$conf.int[,"lower .95"],
                   HR.95H=multicoxSummary$conf.int[,"upper .95"],
                   pvalue=multicoxSummary$coefficients[,"Pr(>|z|)"])
outTab<-cbind(id=rownames(outTab),outTab)
write.table(outTab,file = "multi.Cox.txt",sep = "\t",row.names = F,quote = F)

riskScore<-predict(multicox,type = "risk",newdata = rt)
coxGene=rownames(multicoxSummary$coefficients)
coxGene<-gsub("`","",coxGene)
outCol<-c("futime","fustat",coxGene)
risk<-as.vector(ifelse(riskScore>median(riskScore),"high","low"))
riskOut<-cbind(rt[,outCol],riskScore,risk)
riskOut<-cbind(id=rownames(riskOut),riskOut)
write.table(riskOut,"geneRisk.txt",sep = "\t",quote = F,row.names = F)

pdf(file = "multi.forest.pdf",width = 10,height = 6,onefile = FALSE)
ggforest(multicox,
         cpositions = c(0.02,0.22,0.4),
         fontsize = 0.7,
         refLabel = "reference",
         noDigits = 2)
dev.off()