
inputFile<-"geneRisk.txt"
survFile<-"survival.pdf"
rocFile="ROC.pdf"


library(survival)
library(survminer)
library(timeROC)

rt<-read.table(inputFile,header = T)

diff<-survdiff(Surv(futime,fustat) ~risk,data = rt)
pvalue<-1-pchisq(diff$chisq,df=1)
fit<-survfit(Surv(futime,fustat) ~risk,data = rt)
if(pvalue<0.001){                                
pvalue<-"p<0.001"
}else{
        pvalue<-paste0("p=",sprintf("%.03f",pvalue))
}



surplot<-ggsurvplot(fit,
                    data = rt,
                    conf.int = T,
                    pval = pvalue,
                    pval.size=5,
                    risk.table = T,
                    legend.labs=c("High risk","Low risk"),
                    legend.title="Risk",
                    xlab="Time(years)",
                    break.time.by = 1,
                    risk.table.title="",
                    palette = c("red","blue"),
                    risk.table.height=.25)
pdf(file = survFile,onefile=FALSE,width = 6.5,height = 5.5)
print(surplot)
dev.off()


ROC_rt_5<-timeROC(T=rt$futime,delta = rt$fustat,
                marker = rt$riskScore,cause = 1,
                weighting = "aalen",
                times = 5,ROC = TRUE)
pdf(file = "rocFile_5.pdf",width = 5,height = 5)
plot(ROC_rt,time=5,col="red",title=FALSE,lwd=2)
legend("top",
         paste0("AUC at 5 year:",round(ROC_rt$AUC[3],3)),
       col = "red",lwd = 2,bty = "n")
dev.off()
