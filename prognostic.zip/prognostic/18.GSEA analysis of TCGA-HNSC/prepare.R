
library(limma)

rt<-read.csv("symbol.csv",header = T,
             check.names=FALSE)

rt<-as.matrix(rt)
rownames(rt)<-rt[,1]
exp<-rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data<-matrix(as.numeric(as.matrix(exp)),nrow = nrow(exp),dimnames = dimnames)
data<-avereps(data)

if(grepl("-",colnames(data)[ncol(data)])){
  group=sapply(strsplit(colnames(data),"\\-"),"[",4)
  group=sapply(strsplit(group,""),"[",1)
  group=gsub("2","1",group)
  data=data[,group!=1]
  colnames(data)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-(.*?)\\-.*","\\1\\-\\2\\-\\3",colnames(data))
}

risk<-read.table("geneRisk.txt",header = T,check.names = F,row.names = 1)
samSample<-intersect(colnames(data),rownames(risk))
data<-data[,samSample]
risk<-risk[samSample,]

riskLow<-risk[risk$risk=="low",]
riskHigh<-risk[risk$risk=="high",]
dataLow<-data[,row.names(riskLow)]
dataHigh<-data[,row.names(riskHigh)]

data_sort<-cbind(dataLow,dataHigh)
data_gct<-data.frame("Name"=rownames(data_sort),"Description"="na")
data_gct<-cbind(data_gct,data_sort)
write.table(data_gct,file = "Risk.gct",sep = "\t",row.names = F)

risk_cls<-t(as.data.frame(c(rep("L",ncol(dataLow)),rep("H",ncol(dataHigh)))))
write.table(risk_cls,file = "Risk.cls",sep = " ",row.names = F,quote = F)



