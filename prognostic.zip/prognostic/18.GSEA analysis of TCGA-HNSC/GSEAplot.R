library(plyr)
library(ggplot2)
library(grid)
library(gridExtra)
files<-grep(".tsv",dir(),value = T)
data<-lapply(files,read.delim)
names(data)<-files

dataset<-ldply(data,data.frame)
dataset$pathway<-gsub(".tsv","",dataset$.id)
gseacol<-c("#58CDD9","#7A142C","#5D908A","#431A3D","#91612D","#6E568C","#E0367A","D8D155",
           "#64495D","#7CC767","223D6C","D20A13","FFD121","#088247","#11AA4D")
pGsea<-ggplot(dataset,aes(x=RANK.IN.GENE.LIST,y=RUNNING.ES,colour=pathway,group=pathway))+
                          geom_line(size=1.5)+scale_color_manual(values = gseacol[1:ncol(dataset)])+
                          labs(x="",y="Enrichment_Score",title = "")+scale_x_continuous(expand =c(0,0))+
                          scale_y_continuous(expand = c(0,0),limits = c(min(dataset$RUNNING.ES-0.05),max(dataset$RUNNING.ES+0.05)))+
                            theme_bw()+theme(panel.grid = element_blank())+theme(panel.border = element_blank())+theme(axis.line = element_line(colour = "black"))+theme(axis.line.x =element_blank(),axis.ticks.x =element_blank(),axis.text.x =element_blank())+
                            geom_hline(yintercept = 0)+theme(legend.position = c(0,0),legend.justification = c(0,0))+#legend位置
                            guides(colour=guide_legend(title = NULL))+theme(legend.background = element_blank())+theme(legend.key = element_blank())+theme(legend.key.size = unit(0.5,'cm'))
pGene<-ggplot(dataset,aes(RANK.IN.GENE.LIST,pathway,colour=pathway))+geom_tile()+
  scale_color_manual(values = gseacol[1:ncol(dataset)])+
  labs(x="high risk<------------>low risk",y="",title = "")+
  scale_x_discrete(expand=c(0,0))+scale_y_discrete(expand = c(0,0))+
  theme_bw()+theme(panel.grid=element_blank())+theme(panel.border = element_blank())+theme(axis.line = element_blank())+
  theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),axis.text.y=element_blank())+ guides(color= "none")

gGsea=ggplot_gtable(ggplot_build(pGsea))
gGene=ggplot_gtable(ggplot_build(pGene))
maxWidth=grid::unit.pmax(gGsea$widths,gGene$widths)
gGsea$widths=as.list(maxWidth)
gGene$widths=as.list(maxWidth)
dev.off()

###将图像可视化，保存在“multipleGSEA.pdf"中
pdf("multipleGSEA.pdf",
    width = 7,
    height=5.5)
par(mar=c(5,5,2,5))
grid.arrange(arrangeGrob(gGsea,gGene,nrow = 2,heights = c(.8,.3)))
dev.off()
                            