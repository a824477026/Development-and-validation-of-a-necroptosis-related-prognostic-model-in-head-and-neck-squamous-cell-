
rt<-read.table("geneMatrix.txt",sep = "\t",header = T,check.names = F)
rownames(rt)<-rt$id
sample<-read.table("sample.txt",sep = "\t",header = F,check.names = F)
sample<-sample[,1]
output<-rt[rt$id%in%sample,]
output<-t(output)
output<-data.frame(id=row.names(output),output)
output<-output[-1,]
write.table(output,"output.txt",sep = "\t",row.names = F)

time<-read.table("Time.txt",sep = "\t",check.names = F,header = T)
expTime<-merge(time,output,by="id")
write.table(expTime,"expTime.txt",sep = "\t",row.names = F)
