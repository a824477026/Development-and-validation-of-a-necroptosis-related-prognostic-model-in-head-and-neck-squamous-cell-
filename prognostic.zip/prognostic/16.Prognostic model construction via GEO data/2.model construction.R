library(survival)
library(survminer)
library(glmnet)
coxPfilter=0.05
rt<-read.table("expTime.txt",header = T,sep = "\t",check.names = F,row.names = 1)
rt$futime<-rt$futime/365


multicox<-coxph(Surv(futime,fustat) ~ .,data = rt)
multicoxSummary<-summary(multicox)


outTab<-data.frame(coef=multicoxSummary$coefficients[,"coef"],
                   HR=multicoxSummary$conf.int[,"exp(coef)"],
                   HR.95L=multicoxSummary$conf.int[,"lower .95"],
                   HR.95H=multicoxSummary$conf.int[,"upper .95"],
                   pvalue=multicoxSummary$coefficients[,"Pr(>|z|)"])
outTab<-cbind(id=rownames(outTab),outTab)
write.table(outTab,file = "multi.Cox.txt",sep = "\t",row.names = F,quote = F)

riskScore<-predict(multicox,type = "risk",newdata = rt)
coxGene=rownames(multicoxSummary$coefficients)
coxGene<-gsub("`","",coxGene)
outCol<-c("futime","fustat",coxGene)
risk<-as.vector(ifelse(riskScore>median(riskScore),"high","low"))
write.table(cbind(id=rownames(cbind(rt[,outCol],riskScore,risk)),cbind(rt[,outCol],riskScore,risk)),
            "geneRisk.txt",
            sep = "\t",
            quote = F,
            row.names = F)
