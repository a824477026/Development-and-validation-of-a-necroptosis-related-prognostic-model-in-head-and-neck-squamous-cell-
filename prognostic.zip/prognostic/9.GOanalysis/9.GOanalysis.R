
data_sgni<-read.table("gene.txt",sep = "\t",check.names = F,header = T)


library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(GOplot)
library(enrichplot)
library(clusterProfiler)
library(ggplot2)
entrez_id_full=mapIds(x=org.Hs.eg.db,
                      keys = data_sgni$gene,
                      keytype = "SYMBOL",
                      column = "ENTREZID")
entrez_id<-na.omit(entrez_id_full)
ENTREZID<-data.frame(entrez_id,row.names =nrow(entrez_id))

data_sgni$entrez<-entrez_id

kk<-enrichGO(gene =entrez_id, 
             OrgDb = org.Hs.eg.db,
             pvalueCutoff = 0.05,
             qvalueCutoff=0.05,
             ont = "all",
             readable = T)
write.table(kk,file = "GO.txt",sep = "\t",quote = F,row.names = F)


pdf(file = "barplot.pdf",width = 10,height = 8)
barplot(kk,drop=TRUE,showCategory = 10,split="ONTOLOGY")+facet_grid(ONTOLOGY~.,scales = "free")
dev.off()


pdf(file = "bubble.pdf",width = 10,height = 8)
dotplot(kk,showCategory = 10,split="ONTOLOGY")+facet_grid(ONTOLOGY~.,scales = "free")
dev.off()



ego<-kk@result
go<-data.frame(Category=ego$ONTOLOGY,ID=ego$ID,Term=ego$Description,
               Genes=gsub("/",", ", ego$geneID),adj_pval=ego$p.adjust)

genelist<-data.frame(ID=data_sgni$gene,logFC=data_sgni$logFC)
row.names(genelist)<-genelist[,1]
circ<-circle_dat(go,genelist)


pdf(file = "GOCircle.pdf",width = 11,height = 6)
GOCircle(circ,rad1=2.5,rad2 = 3.5,label.size = 4,nsub = 10)
dev.off()









